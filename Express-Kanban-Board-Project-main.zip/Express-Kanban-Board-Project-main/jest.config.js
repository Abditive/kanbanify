module.exports = {
    testEnvironment: "jsdom"
};